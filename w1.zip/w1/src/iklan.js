const iklan = () => { 
	return `           
╔══✪〘 BIELZINN 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 35 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *PIC PAY,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/5584994195920*
║
╚═〘 𝐵𝐼𝐸𝐿𝑍𝐼𝑁𝑁 𝐵𝑂҈𝑇 〙
`
}
exports.iklan = iklan
