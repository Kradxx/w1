const help = (prefix) => {
	return `

𒍟𝐵𝐼𝐸𝐿𝑍𝐼𝑁𝑁 𝐵𝑂҈𝑇𒍟 🐊😏
𝗜𝗡𝗙𝗢𝗦:

 *O BOT SE ENCONTRA: ON-LINE*
 ▬▬▬▬▬▬▬【☪】▬▬▬▬▬▬▬
 *DONO*: 🔥🎗𝐁𝐢𝐞𝐥𝐳𝐢𝐧𝐧 𝐒𝐡𝐢𝐭🎗🔥
 ▬▬▬▬▬▬▬【☪】▬▬▬▬▬▬▬
 *PREFIXO*:[ / ]
 ▬▬▬▬▬▬▬【☪】▬▬▬▬▬▬▬
 *WHATSAPP*: wa.me/5584994195920
 ▬▬▬▬▬▬▬【☪】▬▬▬▬▬▬▬



        𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗔 𝗕𝗔𝗜𝗫𝗢:

      𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦:

➢【𝗠𝗘𝗟𝗛𝗢𝗥𝗘𝗦】

➛ *${prefix}Sticker* [Faz figurinha]
➛ *${prefix}play* [nome da música]
➛ *${prefix}toimg* [converter figurinha em imagem]
➛ *${prefix}wame* [link do seu whatsapp]
➛ *${prefix}meme* [memes aleatórios]
➛ *${prefix}Bielzinnjokes* [memes2]
➛ *${prefix}tts pt* [seu texto]
➛ *${prefix}ping* [velocidade]
➛ *${prefix}owner ou dono* [info do criador]

➢【𝗡𝗢𝗩𝗢𝗦】

➛ *${prefix}animecry*
➛ *${prefix}chentai [premium]*
➛ *${prefix}gcpf [premium]*
➛ *${prefix}gay [@]*
➛ *${prefix}gbin [premium]*
➛ *${prefix}pack [premium]*
➛ *${prefix}destrava [premium]*
➛ *${prefix}gpessoa [premium]*
➛ *${prefix}spamcall*
➛ *${prefix}play (nome da msc)*

➢【𝗣𝗔𝗥𝗔 𝗚𝗥𝗨𝗣𝗢𝗦】

➛ *${prefix}closegc* [fechar grupo]
➛ *${prefix}opengc* [abrir grupo]
➛ *${prefix}antilink* 1 [anti link]
➛ *${prefix}antiracismo on* [anti racismo]
➛ *${prefix}banir* [banir membro]
➛ *${prefix}admins* [lista se administradores]
➛ *${prefix}marcar* [marcar todos membros]
➛ *${prefix}linkgp* [link do grupo]
➛ *${prefix}promover* [dar adm]
➛ *${prefix}rebaixar* [tirar adm]
➛ *${prefix}bemvindo* 1 [recusso de boas vindas]
➛ *${prefix}grupoinfo* [info]
➛ *${prefix}setdesc* [trocar descrição]
➛ *${prefix}setfoto* [mudar foto]
➛ *${prefix}porno* [porno]
➛ *${prefix}mia* [fotos da mia]

➢【𝗜𝗡𝗧𝗘𝗥𝗔𝗚𝗜𝗥】
➛
➛ *${prefix}figu*
➛ *${prefix}toimg*
➛ *${prefix}Bielzinnjokes (memes aleatórios)*
➛ *${prefix}memeindo*
➛ *${prefix}tts*
➛ *${prefix}lolih [on]*
➛ *${prefix}nsfwloli [off]*
➛ *${prefix}url2img*
➛ *${prefix}leens [na legenda]*
➛ *${prefix}wait [na legenda]*
➛ *${prefix}setprefix*
➛
➢【𝗢𝗨𝗧𝗥𝗢𝗦】
➛
➛ *${prefix}linkgp*
➛ *${prefix}simih [1/0]*
➛ *${prefix}marcar*
➛ *${prefix}add [@]*
➛ *${prefix}banir [@]*
➛ *${prefix}promover [@]*
➛ *${prefix}rebaixar*
➛ *${prefix}admins*
➛ *${prefix}marcar2*
➛ *${prefix}bc [texto]* (ele faz uma ™)
➛ *${prefix}marcar3*
➛ *${prefix}bloqueados*
➛ *${prefix}bloquear [@]*
➛ *${prefix}desbloquear [@]*
➛ *${prefix}limpar*
➛ *${prefix}bc [ *texto* ]*
➛ *${prefix}bemvindo [1/0]*
➛ *${prefix}clonar [@]*
➛ *${prefix}help1*
➛ *${prefix}dono*
➛ *${prefix}owner*
➛ *${prefix}tts [texto]*
➛ *${prefix}setnome*
➛ *${prefix}termux*
➛ *${prefix}setfoto*
➛ *${prefix}grupoinfo*
➛ *${prefix}ytmp4*
➛ *${prefix}bomdia*
➛ *${prefix}boanoite*
➛ *${prefix}marcar*
➛ *${prefix}marcar2*
➛ *${prefix}marcar3*
➛
➢【 𝗜𝗠𝗔𝗚𝗘𝗡𝗦 】
➛
➛ *${prefix}loli* [off]
➛ *${prefix}loli1*
➛ *${prefix}hentai*
➛ *${prefix}dono*
➛ *${prefix}porno*
➛ *${prefix}boanoite*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}mia [aleatórias]*
➛ *${prefix}rize [aleatórias]*
➛ *${prefix}minato [aleatórias]*
➛ *${prefix}boruto [aleatórias]*
➛ *${prefix}hinata [aleatórias]*
➛ *${prefix}sasuke [aleatórias]*
➛ *${prefix}sakura [aleatórias]*
➛ *${prefix}naruto [aleatórias]*
➛ *${prefix}meme*   
➛ *${prefix}lofi*
➛ *${prefix}malkova*
➛ *${prefix}canal*
➛ *${prefix}nsfwloli1*
➛ *${prefix}reislin*
➛
➢【 𝗜𝗡𝗧𝗘𝗟𝗜𝗚𝗘̂𝗡𝗖𝗜𝗔 𝗜𝗔 】
➛
➛ *${prefix}simih 1 (para ativar)*
➛ *${prefix}simih 0 (para desativar)*
➛ *${prefix}simi (sua mensagem)*
➛
➢【𝗘𝗠 𝗧𝗘𝗦𝗧𝗘】
➛
➛ *${prefix}*
➛ *${prefix}*
➛ *${prefix}*
➛
➢【𝗣𝗥𝗘𝗠𝗜𝗨𝗠】
➛
➛ *${prefix}dado*
➛ *${prefix}cekvip*
➛ *${prefix}premiumlist*
➛ *${prefix}delete*
➛ *${prefix}modapk*
➛ *${prefix}indo10*
➛ *${prefix}daftarvip [para virar Premium]*
➛ *${prefix}qrcode*
➛ *${prefix}chentai*
➛ *${prefix}gcpf*
➛ *${prefix}gbin*
➛ *${prefix}pack*
➛ *${prefix}destrava*
➛ *${prefix}gpessoa*

➢【𝗚𝗥𝗨𝗣𝗢】
➛
➛ *${prefix}banir*
➛ *${prefix}leveling [on/off]*
➛ *${prefix}level*
➛ *${prefix}add*
➛ *${prefix}promover*
➛ *${prefix}setfoto [na legenda]*
➛ *${prefix}setname [texto]*
➛ *${prefix}rebaixar*
➛ *${prefix}admins*
➛ *${prefix}marcar*
➛ *${prefix}marcar2*
➛ *${prefix}marcar3*
➛ *${prefix}bemvindo [1/0]*
➛ *${prefix}grupoinfo*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}boanoite*
➛ *${prefix}setdesc*
➛ *${prefix}bug [sua mensagem]*
➛
➢【𝗘𝗦𝗣𝗘𝗖𝗜𝗙𝗜𝗖𝗢 𝗗𝗢 𝗕𝗢𝗧】𝗹
➛
➛ *${prefix}bug [sua mensagem]*
➛ *${prefix}clonar [@]*
➛ *${prefix}dono*
➛ *${prefix}ping [ver velocidade do bot]*
➛ *${prefix}termux*
➛ *${prefix}gay [@]*
➛ *${prefix}wame*
➛ *${prefix}map (nome)*
➛ *${prefix}setppbot (marque uma img)*
➛ *${prefix}pinterest (nome)*
➛ *${prefix}desligar (so para o dono)*
➛ *${prefix}timer*
➛
➢【𝗠𝗔𝗜𝗦 𝗔𝗟𝗚𝗨𝗡𝗦】𝗹
➛
➛ *${prefix}neko*
➛ *${prefix}ttp [texto]*
➛ *${prefix}testime*
➛ *${prefix}tomp3*
➛ *${prefix}modoanime [on/off]*
➛ *${prefix}modonsfw [on/off]*
➛ *${prefix}happymod [jogo/app]*
➛ *${prefix}rize*
➛ *${prefix}ytsearch*
➛ *${prefix}moddroid [jogo/app]*
➛ *${prefix}xvideos [titulo]**
➛ *${prefix}nomegp*
➛ *${prefix}Bielzinnjokes (memes aleatórios)*
➛ *${prefix}animecry*
➛ *${prefix}gay1*
➛ *${prefix}next*
➛ *${prefix}alerta*
➛ *${prefix}belle [img aleatórias]*
➛ *${prefix}pronomeneu [texto]*
➛ *${prefix}hobby*
➛ *𝗡𝗢𝗠𝗘: Bielzinn
➛ *𝗪𝗣𝗣: wa.me/+5584994195920
【 Bielzinn 】
➢【 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗗𝗘 𝗠𝗨𝗦𝗜𝗖𝗔 】

➛ *${prefix} em teste
➛ *${prefix}jogaroxo*
➛ *${prefix} em teste
➛ *${prefix} em teste
➛ *${prefix}narutinho*
➛ *${prefix}}tobi*
➛ *${prefix}rapL*
➛ *${prefix}paypal*
➛ *${prefix}sad*

➢【 𝗢𝗨𝗧𝗥𝗢𝗦 /2 】

*➛ *${prefix}antilink [1/0]*
*➛ *${prefix}brainly [pergunta]*
➛ *${prefix}antiracismo [on/off]*
➛ *${prefix}setnomebot*
➛ *${prefix}meme*
➛ *${prefix}Amordobielzinn*

➢【 𝗜𝗡𝗧𝗘𝗥𝗔𝗧𝗜𝗩𝗢𝗦 】

NOTA »
Mandar a msg sem o prefixo


➛ *${prefix} *beat1*
➛ *${prefix} *beat2*
➛ *${prefix} *hentaisom* (erro)

➢【 𝗗𝗢𝗡𝗢 】

 *𝗡𝗢𝗠𝗘: 🔥🎗𝐁𝐢𝐞𝐥𝐳𝐢𝐧𝐧 𝐒𝐡𝐢𝐭🎗🔥 🐊😎
 *𝗪𝗣𝗣: wa.me/+5584994195920




【 Bielzinn 】`
}

exports.help = help













